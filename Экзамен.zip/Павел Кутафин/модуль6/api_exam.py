import tkinter as Tk
from tkinter import ttk, Button, Label

import re
from docx import Document

import requests
def send_result():
    doc=Document('ПУ/Модуль 6/ ТестКейс.docx')
url='http://127.0.0.1:4444/TransferSimulaor/fullName'
a=requests.get(url).json()['value']
print(a)
pattern=r'[а-яА-ЯёЁ]+[а-яА-ЯёЁ]'
check=re.search(pattern,a)
if check!=None:
    print('валидные данные')
else:
    print('запретные символы')

def window():
    win.destroy()

win = Tk()
win.geometry("500x500")
win.title("валидация")
btn_get=Button(win, text='отправить')
btn_send=Button(win, text='получить')
lbl_fio=Label(win, text='', font='Arail,12')
lbl_check=Label(win, text='', font='Arail,12')
btn_get.grid(row=0, column=10, padx=10, pady=10)
btn_send.grid(row=1, column=10, padx=10, pady=10)
lbl_fio.grid(row=2, column=10, padx=10, pady=10)
lbl_check.grid(row=3, column=10, padx=10, pady=10)

win.mainloop()
